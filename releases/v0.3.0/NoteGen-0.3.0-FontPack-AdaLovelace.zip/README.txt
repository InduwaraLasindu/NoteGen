Ada Lovelace Hand — NoteGen handwriting font
50 confirmed glyphs; averaged up to 32 examples each.
Missing letters/numbers: JKUWXYZjk679
Only explicitly labelled glyphs are mapped. Install Handwriting.ttf in system Fonts settings.
This is a personal print-style outline font; cursive joining and kerning are not inferred.