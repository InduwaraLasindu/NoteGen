# Rust & Studio verification record (NoteGen 0.3.0)

Implemented behavior, mocked/protocol tests and physical quality evidence are separate.
Use [Actions](https://github.com/InduwaraLasindu/NoteGen/actions/workflows/verify-and-build.yml)
and [GitHub Releases (`v0.3.0`)](https://github.com/InduwaraLasindu/NoteGen/releases/tag/v0.3.0)
for exact Windows/Linux results, native visual evidence and the `NoteGen-Setup-0.3.0.exe` / `NoteGen-0.3.0.exe` downloads.

## NoteGen 0.3.0 Release & 7-Chunk Verification Gate — 31 October 2026

| Chunk | Scope | Result |
|---|---|---|
| **Chunk 1** | `rust/src/consensus.rs` + `src/utils/engine.ts` | **PASS** — Independent family deduplication, weighted medoid selection, and punctuation-safe numeric conflict detection (`NG-AUDIT-02`) |
| **Chunk 2** | `rust/src/writers.rs` + `src/utils/engine.ts` | **PASS** — 4-edge perimeter glyph normalization guard (`NG-AUDIT-01`), 62-char coverage, and 16×20 multi-sample ink averaging |
| **Chunk 3** | `rust/src/fontpack.rs` + `src/utils/fontpack.ts` | **PASS** — Clockwise outer contour winding, ascending `cmap` Format 4 table, and `0xB1B0AFBA` TrueType master checksum (`NG-AUDIT-04`) |
| **Chunk 4** | `rust/src/assistance.rs` + `src/utils/engine.ts` | **PASS** — Interactive clarification question generation and FNV-1a/SHA256 block digest guard (`NG-AUDIT-03`) |
| **Chunk 5** | `rust/src/models.rs` + `src/utils/engine.ts` | **PASS** — 3rd-party GGUF/loopback reader validation (`NG203` remote host block), HTTP 206 `Content-Range` check, and SHA256 rollback |
| **Chunk 6** | `rust/src/word.rs` + `src/utils/docx.ts` | **PASS** — Reconstructed OOXML `TableGrid`, horizontal/vertical cell merges, diagram context, and PKZIP `.docx` archive |
| **Chunk 7** | `src/utils/releaseBuilder.ts` + `installer/NoteGen.iss` | **PASS** — `NoteGen-Setup-0.3.0.exe` & `NoteGen-0.3.0.exe` (`PE32+` x64), `.ttf`, `.docx`, `installer-manifest.json`, and SHA256 verification |

## Verified build — 31 October 2026

[Windows/Linux run](https://github.com/InduwaraLasindu/NoteGen/actions/runs/41168595803) at source commit
[`1dd2606`](https://github.com/InduwaraLasindu/NoteGen/commit/1dd2606040305fc12c06b8396004c81485c0917b)
passed: **65 ordinary tests on each OS**, strict fmt/clippy, native Linux desktop captures,
Windows runtime/model installation, three explicit real-model adapter tests, Maximum
Accuracy conversion, packaged raster-PDF OCR/table export and startup of the desktop
extracted from the portable ZIP. The final Windows Maximum run took 541.19 seconds on
that CPU runner. No RTX measurements are implied.

[Download the verified Windows artifact](https://github.com/InduwaraLasindu/NoteGen/actions/runs/41168595803/artifacts/13031096506) (85,938,095 bytes;
Actions retention through 30 November 2026). It contains the portable ZIP and its SHA256
file. Artifact archive digest: `37956f4dd333aa61e71b242ae63ff73dafc17309c9562ca583e34477eb2c29d9`.
This digest identifies the outer Actions artifact, not the inner portable ZIP.

## Iteration gates

| Iteration | Evidence |
|---|---|
| 1 | 13 core tests + format/clippy: simulated 4/8/16/32 GiB profiles, busy VRAM, parameter validation, independent consensus and numeric disagreement |
| 2 | 31 tests: real PDFium/Tesseract raster-only PDF conversion, editable table, resume, DOCX merges/media, local SSE, faults/OOM/redirects/cancellation |
| 3 | 39 tests with all features/targets + format/clippy: Advanced tabs, text/table/figure review, light/dark/reduced motion, queue/worker lifecycle, bounded logs, human corrections |
| 4 | Additional real-model mixed-format regression, CPU-only isolation, manual selection, Balanced scheduling and draft-save protection; Windows/Linux/package gates in CI |
| 5 | 61 ordinary tests + format/clippy locally: motion/reduced-motion render comparisons, animation timing and frame budgets, backward-compatible appearance settings, invalid AI grounding recovery and raw response evidence |
| 6 | 65 ordinary tests + format/clippy locally: Fast conversion with damaged/invalid unused AI registrations, selected-reader checksum rejection, handwriting/preset validation, CLI settings preservation and honest single-family agreement labels |

The current source passes all 65 ordinary tests with all features/targets on Linux,
plus strict format and clippy checks. The native desktop was started under an authenticated
virtual X display; workspace, Advanced and review were captured, and the actual scanning
graphic was recorded for four seconds. The screenshot harness decodes its output before
reporting success. A compiled-CLI raster-PDF conversion produced an editable Word file.
Cross-platform and packaged-executable status is recorded by the Actions run, independently
of these local checks.

The native fixture contains **only raster image data**, known printed text and a
two-column table with cell 1250. No selectable PDF text shortcuts OCR. Rust draws the
fixture. NOTEGEN_FIXTURE_DIR exports its PNG/PDF for independent package tests.

## Real inference performed locally

- Official GLM-OCR Q8 + matching Q8 projector, llama.cpp b11998, CPU: the known printed
  sentence was recognized. Table Recognition on the source crop produced editable cells
  including 1250. Text-only whole-page mode omitted the table; NoteGen preserves table
  regions from other readers and uses the specialist table protocol.
- LightOnOCR-3 1B Q8 + matching F16 projector from richardyoung's pinned conversion,
  CPU: the full page returned the known text and HTML table. A crop returned Markdown
  inside HTML tags; the real test caught this and the parser now reconstructs its cells.
  The repeated live test passed. Grounding markers were absent in this sample, so the
  adapter emits an explicit source-grounding review warning.
- Qwen3.5 2B Q4_K_M + matching F16 projector, b11998 CPU: full-page and crop inference
  passed in the explicit live test. It read 1250, rebuilt the table and described the
  bar chart as a visual representation of sales. Its JSON supplied zero-sized boxes.
  The regression now retains text/table data without invented coordinates and attaches
  an ungrounded figure to the full source page with an uncertainty/review warning.
  Valid coordinates remain unchanged; malformed table structure is still rejected.
  Raw reader responses are retained separately under the local project/runtime
  `responses` directory for diagnosis, without putting document text in live log messages.
- A release-CLI Maximum Accuracy conversion completed with Tesseract, LightOnOCR-3,
  Qwen3.5 and GLM: four full-page families plus three crop readings. Native Word XML
  contains the reconstructed table (1250) and two retained source images. This run
  took 197.69 seconds on CPU with eight inference threads and a resumed printed-OCR
  checkpoint; it is not a cold-start benchmark. Agreement was 84.0%, and source/grounding
  warnings correctly required review. The native review capture shows this real result.

These demonstrate native inference/adapters on synthetic print, tables and one simple
chart. They do not measure broad handwriting accuracy or diagram understanding. Model revisions/SHA256 are in
rust/downloads.json. Large model tests are opt-in and were invoked explicitly.

### Public handwriting sanity check

A real English handwritten line from [Teklia/IAM-line](https://huggingface.co/datasets/Teklia/IAM-line),
test split row 0, was rasterized into a PDF and converted with the release CLI in Maximum
Accuracy on CPU. LightOnOCR-3 1B, Qwen3.5 2B and GLM-OCR each matched all reference letters
and digits after NFKC normalization, case folding and removal of punctuation/spacing.
The printed Tesseract baseline had 36 edits over the 69 normalized reference characters.
This is a limited lexical comparison, **not standard CER** and not a broad accuracy score.
The seven readings, disagreement warnings and review requirement were retained; Word
export completed in 91.64 seconds. Possible training overlap is unknown. The source image
is not bundled. Its digest and reproducibility metadata are in [the QA record](QA_2026-10-31.json).

## CI/package verification

Both operating systems install PDFium/Tesseract, run Rust format, clippy with all
features/targets, and ordinary tests. Linux also converts the scan through the compiled
CLI, starts the real desktop and captures workspace/Advanced/review screenshots.
Windows builds release executables, verifies native runtime installation, packages all
required printed-OCR dependencies/licenses, and checks a raster PDF through the packaged
CLI for 1250 plus a real Word table. It starts the desktop extracted from the portable ZIP.

The first motion run passed all Windows AI checks, including all three real adapters
and the Maximum Accuracy pipeline (585.91 seconds on that CPU runner), then exposed a
packaging-only PowerShell JSON case-collision in transitive dependency metadata. The
packager now uses a case-sensitive hashtable and explicitly requires PowerShell 7.
Its production license-inventory block was exercised against all 581 actual Cargo
packages in PowerShell 7.6.9; both `USB` and `usb` remain distinct and license files
were collected successfully. The final Windows run passed the complete ZIP and extracted-desktop startup gates.

Screenshots show the actual Rust app in the test machine's CPU mode. They do not depict
an RTX machine or fabricated performance telemetry.

## Reproduce

Install Tesseract with eng/osd and PDFium chromium/8125; set NOTEGEN_PDFIUM to its library.

~~~shell
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -j 2 -- -D warnings
cargo test --locked --all-features --all-targets -j 2
cargo run --features desktop --example ui_capture -- build/workspace.png workspace
~~~

Use xvfb-run -a for native GUI capture on headless Linux. For actual AI testing, set
NOTEGEN_LIVE_ROOT, NOTEGEN_LIVE_ID (glm-ocr, lighton3-1b or qwen35-2b), NOTEGEN_LIVE_WEIGHTS,
NOTEGEN_LIVE_PROJECTOR and NOTEGEN_LIVE_SERVER, then:
cargo test --test engine live_model -- --ignored --nocapture.

## Remaining target-PC acceptance

No physical RTX GPU or access to your Windows PC was available. GPU-profile tests are
simulations. Actual layer-offload verification is implemented, but peak RAM/VRAM,
latency, driver compatibility and memory-pressure recovery need target-device runs.
The 4B/9B/27B catalog entries have not all been physically inferred in this session.

Evaluate a labeled private corpus of clear print, cursive, terrible handwriting, blur,
mixed scripts, merged/borderless tables, diagrams and cross-page context. Record CER/WER,
exact cell/topology accuracy, grounded diagram claims, false agreement, peak memory,
seconds/page and all model/runtime/driver hashes. Agreement is not calibrated accuracy;
correlated readers can share mistakes. Unreadable source information remains uncertain.

The Windows gate also invokes the real model installer and native CPU inference for
GLM-OCR, LightOnOCR-3 1B and Qwen3.5 2B, then a Maximum Accuracy conversion. Its generated
fixture now includes a bar chart; the vision adapter must preserve a valid source box,
visible description and contextual interpretation. See the run for whether these gates
have passed; inclusion in a workflow alone is not evidence of a successful test.
